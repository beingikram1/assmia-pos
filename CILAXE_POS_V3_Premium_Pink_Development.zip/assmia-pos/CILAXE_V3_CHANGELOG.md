# CILAXE POS V3 — isolated design package

This package is derived from the uploaded ASSMIA POS MVP ZIP. No GitHub branch, production database, or Vercel deployment was changed.

## Implemented in this package
- CILAXE POS page metadata and navigation branding.
- Premium Pink + White responsive global design system, with accessible focus and reduced-motion handling.
- Read-only `/settings` page showing 15 planned configuration categories.
- Original restaurant POS, KOT, authentication and SQL files retained.

## NOT implemented or verified
- No persisted settings forms, retail POS backend, hotel billing backend, WhatsApp, Razorpay, automatic printing or new subscriptions.
- No build/test run or deployment. The environment needs npm install and configured Supabase test credentials.

## Safe validation
1. Extract the ZIP to a new folder, not your production checkout.
2. Copy `.env.example` to `.env.local` and use development-only Supabase credentials.
3. Run `npm install`, `npm run build`, and `npm run dev`.
4. Review `/login`, `/dashboard`, `/pos`, `/kitchen`, and `/settings` in a development browser.
5. Run tenant-isolation tests in `TEST_PLAN.md` before any production use.
