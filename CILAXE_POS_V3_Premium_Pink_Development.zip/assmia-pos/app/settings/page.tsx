"use client";
import {useWorkspace} from '@/lib/context';
const sections=[
['🏢','Business Profile','Brand identity, business address, GSTIN and contact details'],
['🧾','Billing & Tax','Invoice series, GST configuration, discounts and returns'],
['💳','Payments','Cash, UPI, card and future verified Razorpay integrations'],
['🖨️','Printers & KOT','Receipt templates, station mapping and hardware printer setup'],
['👥','Staff & Permissions','Owner, manager, cashier and kitchen access controls'],
['📦','Inventory','Products, categories, stock levels and stock alerts'],
['🔔','Notifications','New-order sounds, kitchen alerts and reminders'],
['🏪','Restaurant Settings','Tables, takeaway, kitchen workflow and menu settings'],
['🛍️','Retail Settings','Barcode, counters, purchase and returns workflows'],
['🏨','Hotel Studio','Property profile, invoice templates and voucher settings'],
['📈','Reports & Analytics','Sales reports, exports and business metrics'],
['🔒','Security & Backups','Sessions, access audits, backups and recovery'],
['🌐','Appearance & Language','Premium Pink + White theme and localization'],
['💬','WhatsApp & Integrations','E-bills and authorized external connectors'],
['⭐','Subscriptions','Vendor plans, billing cycles and entitlements']
];
export default function Settings(){const {membership}=useWorkspace();return <main className="container"><section className="settingsHero"><h1>Business Settings</h1><p>CILAXE POS · Premium Business Suite</p></section><div className="panel" style={{marginBottom:20}}><b>Settings overview</b><p className="muted">This V3 preview is read-only. These categories are planned configuration areas; no changes are saved to the database. Business: {membership?.restaurant_id||'Not assigned'}.</p></div><div className="settingsGrid">{sections.map(([icon,title,desc])=><article className="settingsCard" key={title}><span className="glyph" aria-hidden="true">{icon}</span><h2>{title}</h2><p>{desc}</p><div style={{marginTop:15,fontSize:11,fontWeight:700,color:'#ad3472'}}>PLANNED MODULE</div></article>)}</div></main>}
