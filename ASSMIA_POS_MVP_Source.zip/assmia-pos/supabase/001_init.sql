-- ASSMIA POS MVP. Run on a NEW Supabase project only.
create extension if not exists pgcrypto;
create table public.restaurants(id uuid primary key default gen_random_uuid(),name text not null check(char_length(trim(name)) between 2 and 150),plan text not null default 'starter' check(plan in ('starter','pro','business')),subscription_status text not null default 'trial' check(subscription_status in ('trial','active','suspended')),next_invoice integer not null default 1,created_at timestamptz not null default now());
create table public.memberships(restaurant_id uuid not null references public.restaurants(id) on delete cascade,user_id uuid not null references auth.users(id) on delete cascade,role text not null check(role in ('owner','manager','cashier','kitchen')),primary key(restaurant_id,user_id));
create index on public.memberships(user_id);
create table public.platform_admins(user_id uuid primary key references auth.users(id) on delete cascade);
create table public.menu_items(id uuid primary key default gen_random_uuid(),restaurant_id uuid not null references public.restaurants(id),name text not null check(length(trim(name)) between 1 and 150),category text not null default 'Other',price_paise integer not null check(price_paise>=0),available boolean not null default true,created_at timestamptz not null default now(),unique(id,restaurant_id));
create index on public.menu_items(restaurant_id);
create table public.orders(id uuid primary key default gen_random_uuid(),restaurant_id uuid not null references public.restaurants(id),invoice_number text not null,table_label text not null default 'Takeaway',status text not null default 'new' check(status in ('new','preparing','ready','served','cancelled')),subtotal_paise bigint not null,discount_paise bigint not null,tax_bps integer not null check(tax_bps between 0 and 10000),tax_paise bigint not null,total_paise bigint not null,payment_method text not null check(payment_method in ('cash','upi','card','unpaid')),created_by uuid not null references auth.users(id),created_at timestamptz not null default now(),unique(restaurant_id,invoice_number),unique(id,restaurant_id));
create index on public.orders(restaurant_id,created_at desc);
create table public.order_items(id uuid primary key default gen_random_uuid(),restaurant_id uuid not null,order_id uuid not null,menu_item_id uuid not null,name_snapshot text not null,unit_price_paise integer not null,quantity integer not null check(quantity between 1 and 99),line_total_paise bigint not null,foreign key(order_id,restaurant_id) references public.orders(id,restaurant_id),foreign key(menu_item_id,restaurant_id) references public.menu_items(id,restaurant_id));
create index on public.order_items(restaurant_id,order_id);
-- Helper executes as migration owner; user_id is always taken from auth.uid(), not passed by clients.
create schema if not exists private;
create or replace function private.role_for(p_restaurant uuid) returns text language sql stable security definer set search_path='' as $$select m.role from public.memberships m where m.restaurant_id=p_restaurant and m.user_id=(select auth.uid()) limit 1$$;
create or replace function private.is_admin() returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.platform_admins p where p.user_id=(select auth.uid()))$$;
revoke all on function private.role_for(uuid) from public;
revoke all on function private.is_admin() from public;
grant usage on schema private to authenticated;
grant execute on function private.role_for(uuid),private.is_admin() to authenticated;
-- SQL RPC: atomic invoice numbering and server validated cart & prices.
create or replace function public.create_restaurant(p_name text) returns uuid language plpgsql security definer set search_path='' as $$
declare v_id uuid;
begin
 if auth.uid() is null then raise exception 'Not authenticated'; end if;
 if char_length(trim(p_name)) not between 2 and 150 then raise exception 'Invalid name'; end if;
 if (select count(*) from public.memberships where user_id=auth.uid())>=1 then raise exception 'Pilot allows one restaurant per account'; end if;
 insert into public.restaurants(name) values(trim(p_name)) returning id into v_id;
 insert into public.memberships(restaurant_id,user_id,role) values(v_id,auth.uid(),'owner');
 return v_id;
end$$;
create or replace function public.create_order(p_restaurant_id uuid,p_items jsonb,p_table_label text,p_discount_paise bigint,p_tax_bps integer,p_payment_method text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare v_item jsonb;v_product record;v_qty integer;v_subtotal bigint:=0;v_tax bigint;v_total bigint;v_order uuid;v_invoice integer;v_invoice_code text;v_item_count integer:=0;
begin
 if auth.uid() is null or private.role_for(p_restaurant_id) not in ('owner','manager','cashier') then raise exception 'Not authorized'; end if;
 if jsonb_typeof(p_items) is distinct from 'array' or jsonb_array_length(p_items) not between 1 and 50 then raise exception 'Invalid cart'; end if;
 if p_discount_paise is null or p_discount_paise<0 or p_tax_bps is null or p_tax_bps<0 or p_tax_bps>10000 or p_payment_method not in ('cash','upi','card','unpaid') then raise exception 'Invalid billing values'; end if;
 if length(coalesce(p_table_label,''))>60 then raise exception 'Invalid table'; end if;
 -- Validate once then insert; transaction rollback on any invalid entry.
 for v_item in select value from jsonb_array_elements(p_items) loop
  if jsonb_typeof(v_item) <> 'object' or (v_item->>'qty') !~ '^[0-9]+$' then raise exception 'Invalid item'; end if;
  v_qty=(v_item->>'qty')::integer;
  if v_qty not between 1 and 99 then raise exception 'Invalid quantity'; end if;
  select id,name,price_paise,available into v_product from public.menu_items where id=(v_item->>'menu_item_id')::uuid and restaurant_id=p_restaurant_id;
  if not found or not v_product.available then raise exception 'Unavailable menu item'; end if;
  v_subtotal=v_subtotal+(v_product.price_paise::bigint*v_qty);v_item_count=v_item_count+1;
 end loop;
 if p_discount_paise>v_subtotal then raise exception 'Discount exceeds bill'; end if;
 v_tax=round((v_subtotal-p_discount_paise)*p_tax_bps::numeric/10000)::bigint;
 v_total=v_subtotal-p_discount_paise+v_tax;
 update public.restaurants set next_invoice=next_invoice+1 where id=p_restaurant_id and subscription_status in ('trial','active') returning next_invoice-1 into v_invoice;
 if not found then raise exception 'Restaurant inactive'; end if;
 v_invoice_code='INV-'||lpad(v_invoice::text,6,'0');
 insert into public.orders(restaurant_id,invoice_number,table_label,subtotal_paise,discount_paise,tax_bps,tax_paise,total_paise,payment_method,created_by)
 values(p_restaurant_id,v_invoice_code,coalesce(nullif(trim(p_table_label),''),'Takeaway'),v_subtotal,p_discount_paise,p_tax_bps,v_tax,v_total,p_payment_method,auth.uid()) returning id into v_order;
 for v_item in select value from jsonb_array_elements(p_items) loop
  v_qty=(v_item->>'qty')::integer;
  select id,name,price_paise into v_product from public.menu_items where id=(v_item->>'menu_item_id')::uuid and restaurant_id=p_restaurant_id;
  insert into public.order_items(restaurant_id,order_id,menu_item_id,name_snapshot,unit_price_paise,quantity,line_total_paise) values(p_restaurant_id,v_order,v_product.id,v_product.name,v_product.price_paise,v_qty,v_product.price_paise::bigint*v_qty);
 end loop;
 return jsonb_build_object('order_id',v_order,'invoice_number',v_invoice_code,'total_paise',v_total);
end$$;
revoke all on function public.create_restaurant(text),public.create_order(uuid,jsonb,text,bigint,integer,text) from public,anon;
grant execute on function public.create_restaurant(text),public.create_order(uuid,jsonb,text,bigint,integer,text) to authenticated;
-- Exposed tables: no public anon access, only operation-specific grants.
revoke all on public.restaurants,public.memberships,public.platform_admins,public.menu_items,public.orders,public.order_items from anon,authenticated;
grant select on public.restaurants,public.memberships,public.platform_admins,public.menu_items,public.orders,public.order_items to authenticated;
grant update(plan,subscription_status) on public.restaurants to authenticated;
grant insert,update on public.menu_items to authenticated;
grant update(status) on public.orders to authenticated;
-- Prevent direct inserts/modification for orders and financial totals. Only validated RPC inserts orders.
-- RLS applies even where authenticated grants exist.
alter table public.restaurants enable row level security;
alter table public.memberships enable row level security;
alter table public.platform_admins enable row level security;
alter table public.menu_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
create policy restaurants_read on public.restaurants for select to authenticated using(private.role_for(id) is not null or (select private.is_admin()));
create policy restaurants_admin_update on public.restaurants for update to authenticated using((select private.is_admin())) with check((select private.is_admin()));
create policy members_read on public.memberships for select to authenticated using(user_id=(select auth.uid()) or (select private.is_admin()));
create policy admins_read on public.platform_admins for select to authenticated using(user_id=(select auth.uid()));
create policy menu_read on public.menu_items for select to authenticated using(private.role_for(restaurant_id) is not null);
create policy menu_insert on public.menu_items for insert to authenticated with check(private.role_for(restaurant_id) in ('owner','manager'));
create policy menu_update on public.menu_items for update to authenticated using(private.role_for(restaurant_id) in ('owner','manager')) with check(private.role_for(restaurant_id) in ('owner','manager'));
create policy orders_read on public.orders for select to authenticated using(private.role_for(restaurant_id) is not null);
create policy orders_status_update on public.orders for update to authenticated using(private.role_for(restaurant_id) is not null) with check(private.role_for(restaurant_id) is not null);
create policy order_items_read on public.order_items for select to authenticated using(private.role_for(restaurant_id) is not null);
-- No anonymous policies; no open membership inserts / platform admin creation.
